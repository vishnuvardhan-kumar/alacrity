# Unittests for the lib.py functions to be placed here

import unittest


class TestParser(unittest.TestCase):
    """ To be built """

    def test_placeholder(self):
        self.assertTrue(True)

    def test_placeholder_2(self):
        self.assertFalse(False)

    def test_placeholder_3(self):
        self.assertEqual(2+2, 4)
